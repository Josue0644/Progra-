﻿// See https://aka.ms/new-console-template for more information
int edad, precio;
string clasificacion, adulto;
Console.WriteLine("* Bienvenido al cine *");
Console.WriteLine("Ingrese su edad");
edad = Int32.Parse(Console.ReadLine());
if (edad < 10)
{
    clasificacion = "PG13";
    Console.WriteLine("El costo de la entrada es Q. 0.00 " + " y su clasificacion es " + clasificacion);
}
else if (edad > 10 && edad < 15)
{
    Console.WriteLine("¿Esta acompañado de un adulto? (Si / No)");
    adulto = (Console.ReadLine());
    if (adulto.ToLower() == "si")
    {
        clasificacion = "PG15";
    }
    else
    {
        clasificacion = "PG13";
    }
    precio = 15;
    Console.WriteLine("El precio es Q. " + precio + " y su clasificacion es " + clasificacion);
}
else if (edad > 15 && edad < 21 )
{
    clasificacion = "PG15";
    precio = 15;
    Console.WriteLine("El precio de su entrada es de Q." + precio + " y su clasificacion es de " + clasificacion);
}
else if (edad > 21 && edad < 60)
{
    precio = 35;
    Console.WriteLine("El precio de su entrada es de Q." + precio + " y puede ver todas las peliculas");
}
else if (edad > 60)
{
    precio = 0;
    Console.WriteLine("El precio es de Q. "+ precio + " y puede ver todas las peliculas");
}
Console.ReadKey();