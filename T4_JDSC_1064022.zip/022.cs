﻿// See https://aka.ms/new-console-template for more information
string a,b,c,d,e,f,g,h,r,j;
Console.WriteLine("Lista de 10 palabras");
Console.WriteLine("Ingrese 10 palabras");
Console.WriteLine("Ingrese la 1 palabra");
a = Console.ReadLine();
Console.WriteLine("Ingrese la 2 palabra");
b = Console.ReadLine(); 
Console.WriteLine("Ingrese la 3 palabra");
c = Console.ReadLine(); 
Console.WriteLine("Ingrese la 4 palabra");
d = Console.ReadLine(); 
Console.WriteLine("Ingrese la 5 palabra");
e = Console.ReadLine(); 
Console.WriteLine("Ingrese la 6 palabra");
f = Console.ReadLine(); 
Console.WriteLine("Ingrese la 7 palabra");
g = Console.ReadLine(); 
Console.WriteLine("Ingrese la 8 palabra");
h = Console.ReadLine(); 
Console.WriteLine("Ingrese la 9 palabra");
r = Console.ReadLine(); 
Console.WriteLine("Ingrese la 10 palabra");
j = Console.ReadLine();

Console.Clear();

if (a ,b ,c ,d ,e ,f ,g ,h ,r , j == variable + || !! || todo en mayusculas || ??)
{
    Console.WriteLine("La palabra que ingreso, es una palabra molesta");
}
else
{
    Console.WriteLine("La palabra no es una palabra molesta");
}
Console.ReadKey();